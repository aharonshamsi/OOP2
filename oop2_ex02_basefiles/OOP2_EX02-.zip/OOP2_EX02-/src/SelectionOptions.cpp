﻿#include "SelectionOptions.h"

SelectionOptions::SelectionOptions(const std::string& label)
	:StringField(label)
{}


void SelectionOptions::validat()
{
	m_isInputValid = false;

	for (int i = 0; i < m_selectionOptions.size(); i++) {
		if (m_userInput == m_selectionOptions[i]) {
			m_isInputValid = true;
			break;
		}
	}
}

void SelectionOptions::printValidationError()
{
	if(!m_isInputValid)
		std::cout << "Error: Invalid preferred time selection. Please choose one of the listed options only." << std::endl;
}
