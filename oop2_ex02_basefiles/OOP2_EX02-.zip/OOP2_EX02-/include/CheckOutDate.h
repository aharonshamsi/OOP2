#pragma once
#include "Date.h"

class CheckOutDate : public Date {

public:
	CheckOutDate(const std::string& label) : Date(label) {};

	void printValidationError() override {
		if (!m_isInputValid) {
			std::cout << "Error: The check-out date is invalid. It must be after the check-in date and in the format YYYY-MM-DD." << std::endl;
			Date::defaultDate();
		}
	};

};
