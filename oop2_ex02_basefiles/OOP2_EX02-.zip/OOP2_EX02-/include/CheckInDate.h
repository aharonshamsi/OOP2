#pragma once
#include "Date.h"

class CheckInDate : public Date {

public:
	CheckInDate(const std::string& label) : Date(label) {};

	void printValidationError() override {
		if (!m_isInputValid) {
			std::cout << "Error: The check-in date is invalid. Please enter a valid date in the format YYYY-MM-DD." << std::endl;
			Date::defaultDate();
		}
	};

};
